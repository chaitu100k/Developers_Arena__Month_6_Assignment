
# Example training script (scikit-learn pipeline)
import pandas as pd
import joblib
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split

def train_model(csv_path, model_out="model.joblib"):
    df = pd.read_csv(csv_path, parse_dates=['timestamp'])
    df = df.sort_values('timestamp')
    # simple features
    df['hour'] = df['timestamp'].dt.hour
    X = df[['sensor_id','hour','avg_speed','occupancy']].fillna(0)
    y = df['vehicle_count']
    X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=42)
    model = RandomForestRegressor(n_estimators=50, random_state=42)
    model.fit(X_train, y_train)
    joblib.dump(model, model_out)
    print("Saved", model_out)

if __name__ == "__main__":
    import sys
    csv = sys.argv[1] if len(sys.argv)>1 else "data/sample_traffic.csv"
    train_model(csv)
